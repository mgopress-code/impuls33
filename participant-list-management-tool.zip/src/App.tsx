import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Gender, Participant, SortDir, SortKey, Team } from "./types";
import { DEFAULT_TEAMS } from "./types";
import { buildSeed } from "./data/seed";
import {
  calcAge,
  exportCsv,
  initials,
  naturalCompare,
  parseDate,
  shortUnion,
} from "./utils/helpers";
import { cn } from "./utils/cn";
import Icon from "./components/Icons";
import { Avatar, GenderBadge, inputCls } from "./components/ui";
import ParticipantModal, { type ParticipantData } from "./components/ParticipantModal";
import ConfirmDialog from "./components/ConfirmDialog";
import RoomInput from "./components/RoomInput";
import RoomsView from "./components/RoomsView";
import ImportDialog from "./components/ImportDialog";
import TeamsView from "./components/TeamsView";
import { TEAM_COLORS } from "./types";
import type { TeamColorKey } from "./types";
import { importCsvToParticipants } from "./utils/helpers";

interface Filters {
  search: string;
  union: string;
  gender: "" | Gender;
  room: string; // "", "__none", "__any", "room:<номер>"
  team: string; // "", "__none", "__any", "team:<id>"
  ageMin: string;
  ageMax: string;
}

const emptyFilters: Filters = {
  search: "",
  union: "",
  gender: "",
  room: "",
  team: "",
  ageMin: "",
  ageMax: "",
};

const sortOptions: { key: SortKey; label: string }[] = [
  { key: "num", label: "№ п/п" },
  { key: "fio", label: "Ф.И.О." },
  { key: "gender", label: "Пол" },
  { key: "union", label: "Профсоюз" },
  { key: "workplace", label: "Место работы" },
  { key: "birth", label: "Дата рождения" },
  { key: "age", label: "Возраст" },
  { key: "passport", label: "Паспорт" },
  { key: "issuedDate", label: "Дата выдачи паспорта" },
  { key: "phone", label: "Телефон" },
  { key: "room", label: "Номер проживания" },
  { key: "team", label: "Команда" },
] as { key: SortKey; label: string }[];

function sortValue(
  p: Participant,
  key: SortKey,
  numOf: Map<string, number>,
  teamOf: Map<string, Team> | null
): string | number | null {
  switch (key) {
    case "num":
      return numOf.get(p.id) ?? 0;
    case "fio":
      return p.fio;
    case "gender":
      return p.gender === "М" ? 0 : 1;
    case "union":
      return shortUnion(p.union);
    case "workplace":
      return p.workplace || null;
    case "birth":
      return parseDate(p.birth)?.getTime() ?? null;
    case "age": {
      const t = parseDate(p.birth)?.getTime();
      return t === undefined ? null : -t;
    }
    case "passport":
      return p.passport || null;
    case "issuedDate":
      return parseDate(p.issuedDate)?.getTime() ?? null;
    case "phone":
      return p.phone || null;
    case "room":
      return p.room || null;
    case "team": {
      const t = teamOf?.get(p.id);
      return t ? t.name : null;
    }
  }
}

function SortTh({
  label,
  k,
  sort,
  onSort,
  className,
}: {
  label: string;
  k: SortKey;
  sort: { key: SortKey; dir: SortDir };
  onSort: (k: SortKey) => void;
  className?: string;
}) {
  const active = sort.key === k;
  return (
    <th
      scope="col"
      className={cn("whitespace-nowrap px-3 py-3 text-left text-xs font-semibold uppercase tracking-wide", className)}
      aria-sort={active ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}
    >
      <button
        onClick={() => onSort(k)}
        className={cn(
          "group inline-flex items-center gap-1 uppercase transition hover:text-indigo-700",
          active ? "text-indigo-700" : "text-slate-500"
        )}
      >
        {label}
        <Icon
          name={active ? (sort.dir === "asc" ? "up" : "down") : "updown"}
          size={13}
          className={active ? "" : "opacity-40 group-hover:opacity-100"}
        />
      </button>
    </th>
  );
}

type ModalState = null | { mode: "add" } | { mode: "edit"; id: string };

interface AppState {
  participants: Participant[];
  teams: Team[];
}

const STORAGE_KEY = "forum-participants-v1";

function loadInitial(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // старый формат — массив участников
        return { participants: parsed, teams: DEFAULT_TEAMS };
      }
      if (parsed && Array.isArray(parsed.participants)) {
        return {
          participants: parsed.participants,
          teams: Array.isArray(parsed.teams) && parsed.teams.length > 0
            ? parsed.teams
            : DEFAULT_TEAMS,
        };
      }
    }
  } catch {
    /* ignore */
  }
  return { participants: buildSeed(), teams: DEFAULT_TEAMS };
}

interface ConfirmState {
  title: string;
  message: string;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void;
}

export default function App() {
  const initial = useMemo(loadInitial, []);
  const [participants, setParticipants] = useState<Participant[]>(initial.participants);
  const [teams, setTeams] = useState<Team[]>(initial.teams);
  const [tab, setTab] = useState<"list" | "rooms" | "teams">("list");
  const [filters, setFilters] = useState<Filters>(emptyFilters);
  const [sort, setSort] = useState<{ key: SortKey; dir: SortDir }>({ key: "num", dir: "asc" });
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [modal, setModal] = useState<ModalState>(null);
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [bulkRoom, setBulkRoom] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  const [importData, setImportData] = useState<{
    data: ParticipantData[];
    errors: string[];
    teams: { name: string; color: string; curators: string[] }[];
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Синхронизация memberIds команд с реально существующими участниками
  useEffect(() => {
    const valid = new Set(participants.map((p) => p.id));
    const changed = teams.some((t) => t.memberIds.some((id) => !valid.has(id)));
    if (changed) {
      setTeams((ts) =>
        ts.map((t) => ({ ...t, memberIds: t.memberIds.filter((id) => valid.has(id)) }))
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [participants]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ participants, teams }));
    } catch {
      /* ignore */
    }
  }, [participants, teams]);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  /* ---------- производные данные ---------- */
  const numOf = useMemo(() => new Map(participants.map((p, i) => [p.id, i + 1])), [participants]);

  const unions = useMemo(() => [...new Set(participants.map((p) => p.union))], [participants]);

  const rooms = useMemo(
    () => [...new Set(participants.map((p) => p.room).filter(Boolean))].sort(naturalCompare),
    [participants]
  );

  const roomInfo = useMemo(() => {
    const m = new Map<string, { m: number; f: number }>();
    for (const p of participants) {
      if (!p.room) continue;
      const e = m.get(p.room) ?? { m: 0, f: 0 };
      if (p.gender === "М") e.m++;
      else e.f++;
      m.set(p.room, e);
    }
    return m;
  }, [participants]);

  const participantTeam = useMemo(() => {
    const m = new Map<string, Team>();
    for (const t of teams) {
      for (const id of t.memberIds) {
        m.set(id, t);
      }
    }
    return m;
  }, [teams]);

  const stats = useMemo(() => {
    const male = participants.filter((p) => p.gender === "М").length;
    const placed = participants.filter((p) => p.room).length;
    const assignedToTeams = participants.filter((p) => teams.some((t) => t.memberIds.includes(p.id))).length;
    let mixed = 0;
    roomInfo.forEach((v) => {
      if (v.m > 0 && v.f > 0) mixed++;
    });
    return {
      total: participants.length,
      male,
      female: participants.length - male,
      placed,
      unplaced: participants.length - placed,
      rooms: roomInfo.size,
      mixed,
      assignedToTeams,
    };
  }, [participants, roomInfo]);

    const visible = useMemo(() => {
    const q = filters.search.trim().toLowerCase();
    const min = filters.ageMin === "" ? null : Number(filters.ageMin);
    const max = filters.ageMax === "" ? null : Number(filters.ageMax);
    const now = new Date();

    const rows = participants.filter((p) => {
      if (filters.union && p.union !== filters.union) return false;
      if (filters.gender && p.gender !== filters.gender) return false;
      if (filters.room === "__none" && p.room) return false;
      if (filters.room === "__any" && !p.room) return false;
      if (filters.room.startsWith("room:") && p.room !== filters.room.slice(5)) return false;
      const team = participantTeam.get(p.id);
      if (filters.team === "__none" && team) return false;
      if (filters.team === "__any" && !team) return false;
      if (filters.team.startsWith("team:") && team?.id !== filters.team.slice(5)) return false;
      if (min !== null || max !== null) {
        const age = calcAge(p.birth, now);
        if (age === null) return false;
        if (min !== null && age < min) return false;
        if (max !== null && age > max) return false;
      }
      if (q) {
        const teamName = team?.name ?? "";
        const curators = team?.curators?.join(" ") ?? "";
        const hay = [
          p.fio, p.workplace, p.union, p.passport, p.issuedBy, p.phone, p.room, p.birth, p.note, teamName, curators,
        ]
          .join(" ")
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    const dir = sort.dir === "asc" ? 1 : -1;
    return rows.sort((a, b) => {
      const va = sortValue(a, sort.key, numOf, participantTeam);
      const vb = sortValue(b, sort.key, numOf, participantTeam);
      if (va === null && vb === null) return (numOf.get(a.id) ?? 0) - (numOf.get(b.id) ?? 0);
      if (va === null) return 1;
      if (vb === null) return -1;
      let c: number;
      if (typeof va === "number" && typeof vb === "number") c = va - vb;
      else c = naturalCompare(String(va), String(vb));
      if (c !== 0) return c * dir;
      return (numOf.get(a.id) ?? 0) - (numOf.get(b.id) ?? 0);
    });
  }, [participants, filters, sort, numOf]);

  const activeFilterCount =
    (filters.search ? 1 : 0) +
    (filters.union ? 1 : 0) +
    (filters.gender ? 1 : 0) +
    (filters.room ? 1 : 0) +
    (filters.team ? 1 : 0) +
    (filters.ageMin !== "" || filters.ageMax !== "" ? 1 : 0);

  const selectedIds = useMemo(
    () => participants.filter((p) => selected.has(p.id)).map((p) => p.id),
    [participants, selected]
  );
  const allVisibleSelected = visible.length > 0 && visible.every((p) => selected.has(p.id));

  /* ---------- действия ---------- */
  const patchFilters = (patch: Partial<Filters>) => setFilters((f) => ({ ...f, ...patch }));

  const onSort = (k: SortKey) => {
    setSort((s) => {
      if (s.key !== k) return { key: k, dir: "asc" };
      if (s.dir === "asc") return { key: k, dir: "desc" };
      return { key: "num", dir: "asc" };
    });
  };

  const toggleSelect = (id: string) =>
    setSelected((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const toggleAllVisible = () =>
    setSelected((s) => {
      const n = new Set(s);
      if (allVisibleSelected) visible.forEach((p) => n.delete(p.id));
      else visible.forEach((p) => n.add(p.id));
      return n;
    });

  const updateOne = useCallback((id: string, patch: Partial<Participant>) => {
    setParticipants((list) => list.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  }, []);

  const assignRoom = useCallback((ids: string[], room: string) => {
    const set = new Set(ids);
    setParticipants((list) => list.map((p) => (set.has(p.id) ? { ...p, room } : p)));
  }, []);

  const removeIds = (ids: string[]) => {
    const set = new Set(ids);
    setParticipants((list) => list.filter((p) => !set.has(p.id)));
    setSelected((s) => {
      const n = new Set(s);
      ids.forEach((id) => n.delete(id));
      return n;
    });
  };

  const askDelete = (p: Participant) =>
    setConfirm({
      title: "Удалить участника?",
      message: `«${p.fio}» будет удалён(а) из списка. Остальные номера п/п пересчитаются автоматически.`,
      confirmLabel: "Удалить",
      onConfirm: () => {
        removeIds([p.id]);
        setConfirm(null);
        setToast("Участник удалён");
      },
    });

  const askDeleteSelected = () =>
    setConfirm({
      title: `Удалить выбранных (${selectedIds.length})?`,
      message: "Выбранные участники будут безвозвратно удалены из списка.",
      confirmLabel: "Удалить",
      onConfirm: () => {
        removeIds(selectedIds);
        setConfirm(null);
        setToast(`Удалено участников: ${selectedIds.length}`);
      },
    });

  const askReset = () =>
    setConfirm({
      title: "Вернуть исходный список?",
      message: "Все изменения (добавленные, удалённые и изменённые участники, номера проживания) будут потеряны.",
      confirmLabel: "Сбросить",
      danger: true,
      onConfirm: () => {
        setParticipants(buildSeed());
        setTeams(DEFAULT_TEAMS.map((t) => ({ ...t, memberIds: [] })));
        setSelected(new Set());
        setFilters(emptyFilters);
        setSort({ key: "num", dir: "asc" });
        setConfirm(null);
        setToast("Исходный список восстановлен (с тремя командами)");
      },
    });

  const saveModal = (data: ParticipantData) => {
    if (modal?.mode === "edit") {
      updateOne(modal.id, data);
      setToast("Изменения сохранены");
    } else {
      const id = `new-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
      const created: Participant = { id, ...data };
      setParticipants((list) => {
        // вставляем в конец блока своего профсоюза
        let idx = -1;
        list.forEach((p, i) => {
          if (p.union === created.union) idx = i;
        });
        const next = [...list];
        if (idx === -1) next.push(created);
        else next.splice(idx + 1, 0, created);
        return next;
      });
      setToast("Участник добавлен");
    }
    setModal(null);
  };

  const applyBulkRoom = () => {
    const r = bulkRoom.trim();
    if (!r) {
      setToast("Введите номер проживания");
      return;
    }
    assignRoom(selectedIds, r);
    setToast(`Номер ${r} назначен: ${selectedIds.length} чел.`);
  };

  const clearBulkRoom = () => {
    assignRoom(selectedIds, "");
    setToast("Номер проживания очищен");
  };

  const doExport = () => {
    exportCsv(
      participants,
      (id) => numOf.get(id) ?? 0,
      "uchastniki-foruma.csv",
      {
        teamOf: (id) => {
          const t = participantTeam.get(id);
          if (!t) return null;
          return { name: t.name, color: t.color, curators: t.curators };
        },
      }
    );
    setToast(`Экспортировано строк: ${participants.length}`);
  };

  const onFileSelected = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const text = String(reader.result ?? "");
        const { ok, errors, teams } = importCsvToParticipants(text);
        setImportData({ data: ok, errors, teams });
      } catch (e) {
        setToast("Не удалось прочитать файл: " + (e instanceof Error ? e.message : "ошибка"));
      }
    };
    reader.onerror = () => setToast("Ошибка чтения файла");
    reader.readAsText(file, "utf-8");
  };

  const applyImport = (mode: "replace" | "append") => {
    if (!importData) return;

    // Собираем записи и команды
    const importedTeams = importData.teams as { name: string; color: string; curators: string[] }[];
    const validColors = Object.keys(TEAM_COLORS);
    const palette = validColors;

    // Режим replace: используем импортированные команды (если есть), иначе оставляем текущие по умолчанию?
    // Логика: при replace — команды полностью из файла (если в файле они есть), иначе дефолтные.
    // При append — сливаем команды по имени: добавляем недостающие, для известных подливаем кураторов.
    let finalTeams: Team[];
    const usedColors = new Set<string>();
    const withColor = (t: { name: string; color: string; curators: string[] }): Team => {
      let color = t.color;
      if (!color || !validColors.includes(color) || usedColors.has(color)) {
        color = palette.find((c) => !usedColors.has(c)) ?? "blue";
      }
      usedColors.add(color);
      return {
        id: `imp-team-${t.name}-${Math.random().toString(36).slice(2, 6)}`,
        name: t.name,
        color,
        curators: t.curators,
        memberIds: [],
      };
    };

    if (mode === "replace") {
      finalTeams = importedTeams.length > 0
        ? importedTeams.map(withColor)
        : DEFAULT_TEAMS.map((t) => ({ ...t, memberIds: [] }));
    } else {
      finalTeams = teams.map((t) => ({ ...t, memberIds: [], curators: [...t.curators] }));
      for (const it of importedTeams) {
        const existing = finalTeams.find((t) => t.name.toLowerCase() === it.name.toLowerCase());
        if (existing) {
          for (const cur of it.curators) {
            if (!existing.curators.some((c) => c.toLowerCase() === cur.toLowerCase())) {
              existing.curators.push(cur);
            }
          }
        } else {
          const team = withColor(it);
          finalTeams.push(team);
        }
      }
    }

    const teamByName = new Map<string, Team>();
    for (const t of finalTeams) teamByName.set(t.name.toLowerCase(), t);

    const newRows: Participant[] = importData.data.map((d, i) => {
      const { team: teamName, ...rest } = d;
      const id = `imp-${Date.now().toString(36)}-${i}`;
      const p: Participant = { id, ...rest };
      if (teamName) {
        const t = teamByName.get(teamName.toLowerCase());
        if (t) t.memberIds.push(id);
      }
      return p;
    });

    if (mode === "replace") {
      setParticipants(newRows);
      setTeams(finalTeams);
    } else {
      setParticipants((list) => {
        const next = [...list];
        for (const p of newRows) {
          let idx = -1;
          next.forEach((ex, i) => {
            if (ex.union === p.union) idx = i;
          });
          if (idx === -1) next.push(p);
          else next.splice(idx + 1, 0, p);
        }
        return next;
      });
      setTeams((existing) => {
        // добавить новых (не было), для существующих — подлить memberIds из файла
        const next = existing.map((t) => ({ ...t, memberIds: [...t.memberIds] }));
        const byName = new Map(next.map((t) => [t.name.toLowerCase(), t]));
        for (const ft of finalTeams) {
          const ex = byName.get(ft.name.toLowerCase());
          if (ex) {
            for (const mid of ft.memberIds) {
              if (!ex.memberIds.includes(mid)) ex.memberIds.push(mid);
            }
            for (const c of ft.curators) {
              if (!ex.curators.some((x) => x.toLowerCase() === c.toLowerCase())) ex.curators.push(c);
            }
          } else {
            next.push(ft);
          }
        }
        return next;
      });
    }

    setToast(
      mode === "replace"
        ? `Список заменён: ${newRows.length} участников, ${finalTeams.length} команд`
        : `Добавлено: ${newRows.length} участников, команды обновлены`
    );
    setImportData(null);
  };

  const askClearAll = () =>
    setConfirm({
      title: "Очистить весь список?",
      message:
        "Будут удалены все участники, распределение по командам и номерам. Команды (названия, цвета, кураторы) при этом останутся.",
      confirmLabel: "Очистить",
      danger: true,
      onConfirm: () => {
        setParticipants([]);
        setTeams((ts) => ts.map((t) => ({ ...t, memberIds: [] })));
        setSelected(new Set());
        setFilters(emptyFilters);
        setConfirm(null);
        setToast("Список и состав команд очищены");
      },
    });

  const editing = modal?.mode === "edit" ? participants.find((p) => p.id === modal.id) ?? null : null;

  /* ---------- UI ---------- */
  const statCards: {
    label: string;
    value: number;
    tone: string;
    onClick: () => void;
    active: boolean;
    hint?: string;
  }[] = [
    {
      label: "Всего участников",
      value: stats.total,
      tone: "text-slate-900",
      onClick: () => setFilters(emptyFilters),
      active: activeFilterCount === 0,
    },
    {
      label: "Мужчины",
      value: stats.male,
      tone: "text-sky-600",
      onClick: () => patchFilters({ gender: filters.gender === "М" ? "" : "М" }),
      active: filters.gender === "М",
    },
    {
      label: "Женщины",
      value: stats.female,
      tone: "text-rose-500",
      onClick: () => patchFilters({ gender: filters.gender === "Ж" ? "" : "Ж" }),
      active: filters.gender === "Ж",
    },
    {
      label: "Размещены",
      value: stats.placed,
      tone: "text-emerald-600",
      onClick: () => patchFilters({ room: filters.room === "__any" ? "" : "__any" }),
      active: filters.room === "__any",
    },
    {
      label: "Без номера",
      value: stats.unplaced,
      tone: "text-amber-600",
      onClick: () => patchFilters({ room: filters.room === "__none" ? "" : "__none" }),
      active: filters.room === "__none",
    },
    {
      label: "Занято номеров",
      value: stats.rooms,
      tone: "text-indigo-600",
      onClick: () => setTab("rooms"),
      active: false,
      hint: stats.mixed ? `смешанных: ${stats.mixed}` : undefined,
    },
    {
      label: "В командах",
      value: stats.assignedToTeams,
      tone: "text-fuchsia-600",
      onClick: () => setTab("teams"),
      active: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      {/* Шапка */}
      <header className="bg-gradient-to-br from-indigo-700 via-indigo-600 to-sky-600 text-white print:bg-white print:text-black">
        <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-indigo-200 print:text-slate-500">
                Список участников
              </p>
              <h1 className="mt-1 text-2xl font-bold leading-tight sm:text-3xl">
                Республиканский профсоюзный образовательный форум
              </h1>
              <p className="mt-1 text-sm text-indigo-100 print:text-slate-600">
                Добавление, удаление, редактирование, фильтры, сортировка и размещение участников
              </p>
            </div>
            <div className="flex flex-wrap gap-2 print:hidden">
              <button
                onClick={() => setModal({ mode: "add" })}
                className="inline-flex items-center gap-2 rounded-lg bg-white px-4 py-2.5 text-sm font-semibold text-indigo-700 shadow transition hover:bg-indigo-50"
              >
                <Icon name="plus" size={18} /> Добавить участника
              </button>
              <div className="flex gap-1 rounded-lg bg-white/15 p-0.5 ring-1 ring-inset ring-white/30">
                <button
                  onClick={doExport}
                  className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-white transition hover:bg-white/20"
                  title="Скачать таблицу целиком в CSV для Excel"
                >
                  <Icon name="download" size={16} /> CSV
                </button>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-white transition hover:bg-white/20"
                  title="Загрузить список из CSV-файла"
                >
                  <Icon name="upload" size={16} /> Загрузить
                </button>
              </div>
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 rounded-lg bg-white/15 px-4 py-2.5 text-sm font-medium text-white ring-1 ring-inset ring-white/30 transition hover:bg-white/25"
              >
                <Icon name="printer" size={17} /> Печать
              </button>
              <button
                onClick={askReset}
                className="inline-flex items-center gap-2 rounded-lg bg-white/15 px-4 py-2.5 text-sm font-medium text-white ring-1 ring-inset ring-white/30 transition hover:bg-white/25"
                title="Вернуть исходный список из 120 участников"
              >
                <Icon name="reset" size={17} /> К исходным
              </button>
              <button
                onClick={askClearAll}
                className="inline-flex items-center gap-2 rounded-lg bg-rose-600/90 px-4 py-2.5 text-sm font-medium text-white ring-1 ring-inset ring-rose-300/40 transition hover:bg-rose-600"
                title="Удалить всех участников"
              >
                <Icon name="trash" size={16} /> Очистить всё
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,text/csv,text/plain"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onFileSelected(f);
                  e.target.value = "";
                }}
              />
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6">
        {/* Статистика */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6 print:hidden">
          {statCards.map((c) => (
            <button
              key={c.label}
              onClick={c.onClick}
              className={cn(
                "rounded-xl border bg-white p-4 text-left shadow-sm transition hover:shadow-md",
                c.active ? "border-indigo-400 ring-2 ring-indigo-200" : "border-slate-200"
              )}
            >
              <div className="text-xs font-medium text-slate-500">{c.label}</div>
              <div className={cn("mt-1 text-3xl font-bold tabular-nums", c.tone)}>{c.value}</div>
              {c.hint && <div className="mt-0.5 text-xs font-medium text-amber-600">⚠ {c.hint}</div>}
            </button>
          ))}
        </div>

        {/* Вкладки */}
        <div className="mt-6 flex gap-1 border-b border-slate-300 print:hidden">
          {(
            [
              ["list", "Список участников", "list"],
              ["rooms", "Размещение", "bed"],
              ["teams", "Команды", "users"],
            ] as const
          ).map(([k, label, icon]) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={cn(
                "-mb-px inline-flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-semibold transition",
                tab === k
                  ? "border-indigo-600 text-indigo-700"
                  : "border-transparent text-slate-500 hover:text-slate-800"
              )}
            >
              <Icon name={icon} size={17} /> {label}
            </button>
          ))}
        </div>

        <datalist id="rooms-list">
          {rooms.map((r) => (
            <option key={r} value={r} />
          ))}
        </datalist>

        {tab === "rooms" ? (
          <div className="mt-6">
            <RoomsView
              participants={participants}
              onAssign={assignRoom}
              onEdit={(id) => setModal({ mode: "edit", id })}
            />
          </div>
        ) : tab === "teams" ? (
          <div className="mt-6">
            <TeamsView
              participants={participants}
              teams={teams}
              onTeamsChange={setTeams}
              onEditParticipant={(id) => setModal({ mode: "edit", id })}
              onConfirm={setConfirm}
              onToast={setToast}
            />
          </div>
        ) : (
          <>
            {/* Фильтры */}
            <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm print:hidden">
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-12">
                <div className="relative md:col-span-2 xl:col-span-4">
                  <Icon
                    name="search"
                    size={17}
                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    value={filters.search}
                    onChange={(e) => patchFilters({ search: e.target.value })}
                    placeholder="Поиск: Ф.И.О., место работы, паспорт, телефон, номер…"
                    className={cn(inputCls, "pl-9")}
                  />
                </div>

                <select
                  value={filters.union}
                  onChange={(e) => patchFilters({ union: e.target.value })}
                  className={cn(inputCls, "xl:col-span-4")}
                  aria-label="Фильтр по профсоюзу"
                >
                  <option value="">Все профсоюзы ({unions.length})</option>
                  {unions.map((u) => (
                    <option key={u} value={u}>
                      {shortUnion(u)} ({participants.filter((p) => p.union === u).length})
                    </option>
                  ))}
                </select>

                <select
                  value={filters.room}
                  onChange={(e) => patchFilters({ room: e.target.value })}
                  className={cn(inputCls, "xl:col-span-3")}
                  aria-label="Фильтр по проживанию"
                >
                  <option value="">Проживание: все</option>
                  <option value="__any">Размещены (есть номер)</option>
                  <option value="__none">Без номера</option>
                  {rooms.length > 0 && (
                    <optgroup label="Конкретный номер">
                      {rooms.map((r) => (
                        <option key={r} value={`room:${r}`}>
                          Номер {r} ({roomInfo.get(r)!.m + roomInfo.get(r)!.f} чел.)
                        </option>
                      ))}
                    </optgroup>
                  )}
                </select>

                <select
                  value={filters.team}
                  onChange={(e) => patchFilters({ team: e.target.value })}
                  className={cn(inputCls, "xl:col-span-3")}
                  aria-label="Фильтр по команде"
                >
                  <option value="">Команды: все</option>
                  <option value="__any">В команде</option>
                  <option value="__none">Без команды</option>
                  {teams.length > 0 && (
                    <optgroup label="Конкретная команда">
                      {teams.map((t) => {
                        const cnt = t.memberIds.length;
                        return (
                          <option key={t.id} value={`team:${t.id}`}>
                            {t.name} ({cnt} чел.)
                          </option>
                        );
                      })}
                    </optgroup>
                  )}
                </select>

                {/* Пол */}
                <div className="flex items-center gap-2 xl:col-span-3">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">Пол</span>
                  <div className="flex flex-1 overflow-hidden rounded-lg border border-slate-300 shadow-sm">
                    {(
                      [
                        ["", "Все"],
                        ["М", "♂ Муж."],
                        ["Ж", "♀ Жен."],
                      ] as const
                    ).map(([v, label]) => (
                      <button
                        key={v}
                        onClick={() => patchFilters({ gender: v })}
                        className={cn(
                          "flex-1 px-3 py-2 text-sm font-medium transition",
                          filters.gender === v
                            ? "bg-indigo-600 text-white"
                            : "bg-white text-slate-600 hover:bg-slate-50"
                        )}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Возраст */}
                <div className="flex items-center gap-2 xl:col-span-3">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">Возраст</span>
                  <input
                    type="number"
                    min={0}
                    max={120}
                    value={filters.ageMin}
                    onChange={(e) => patchFilters({ ageMin: e.target.value })}
                    placeholder="от"
                    className={cn(inputCls, "min-w-0")}
                  />
                  <span className="text-slate-400">–</span>
                  <input
                    type="number"
                    min={0}
                    max={120}
                    value={filters.ageMax}
                    onChange={(e) => patchFilters({ ageMax: e.target.value })}
                    placeholder="до"
                    className={cn(inputCls, "min-w-0")}
                  />
                </div>

                {/* Сортировка */}
                <div className="flex items-center gap-2 xl:col-span-4">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">Сортировка</span>
                  <select
                    value={sort.key}
                    onChange={(e) => setSort({ key: e.target.value as SortKey, dir: "asc" })}
                    className={cn(inputCls, "min-w-0")}
                    aria-label="Сортировать по"
                  >
                    {sortOptions.map((o) => (
                      <option key={o.key} value={o.key}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => setSort((s) => ({ ...s, dir: s.dir === "asc" ? "desc" : "asc" }))}
                    className="inline-flex h-[38px] shrink-0 items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 text-sm font-medium text-slate-700 shadow-sm transition hover:bg-slate-50"
                    title="Изменить направление сортировки"
                  >
                    <Icon name={sort.dir === "asc" ? "up" : "down"} size={15} />
                    {sort.dir === "asc" ? "А→Я" : "Я→А"}
                  </button>
                </div>

                <div className="flex items-center justify-end xl:col-span-2">
                  <button
                    onClick={() => setFilters(emptyFilters)}
                    disabled={activeFilterCount === 0}
                    className="inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-indigo-600 transition hover:bg-indigo-50 disabled:cursor-not-allowed disabled:text-slate-400 disabled:hover:bg-transparent"
                  >
                    <Icon name="filter" size={15} />
                    Сбросить{activeFilterCount > 0 ? ` (${activeFilterCount})` : ""}
                  </button>
                </div>
              </div>
            </section>

            {/* Массовые действия */}
            {selectedIds.length > 0 && (
              <div className="sticky top-2 z-30 mt-4 flex flex-wrap items-center gap-3 rounded-xl border border-indigo-200 bg-indigo-50 px-4 py-3 shadow-md print:hidden">
                <span className="text-sm font-semibold text-indigo-900">Выбрано: {selectedIds.length}</span>
                <div className="flex items-center gap-2">
                  <input
                    list="rooms-list"
                    value={bulkRoom}
                    onChange={(e) => setBulkRoom(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && applyBulkRoom()}
                    placeholder="Номер проживания"
                    className={cn(inputCls, "w-44 py-1.5")}
                  />
                  <button
                    onClick={applyBulkRoom}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700"
                  >
                    <Icon name="bed" size={15} /> Заселить
                  </button>
                  <button
                    onClick={clearBulkRoom}
                    className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                  >
                    Очистить номер
                  </button>
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <button
                    onClick={askDeleteSelected}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3 py-1.5 text-sm font-semibold text-white shadow-sm transition hover:bg-rose-700"
                  >
                    <Icon name="trash" size={15} /> Удалить
                  </button>
                  <button
                    onClick={() => setSelected(new Set())}
                    className="rounded-lg px-3 py-1.5 text-sm font-medium text-slate-600 transition hover:bg-white"
                  >
                    Снять выделение
                  </button>
                </div>
              </div>
            )}

            {/* Таблица */}
            <div className="mt-4 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
              <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3 text-sm">
                <span className="text-slate-600">
                  Показано <b className="text-slate-900">{visible.length}</b> из{" "}
                  <b className="text-slate-900">{participants.length}</b>
                </span>
                <span className="hidden text-xs text-slate-400 sm:inline print:hidden">
                  Клик по заголовку — сортировка · клик по полу — смена пола · номер проживания редактируется прямо в таблице
                </span>
              </div>

              <div className="max-h-[75vh] overflow-auto print:max-h-none print:overflow-visible">
                <table className="w-full min-w-[1250px] border-collapse text-sm">
                  <thead className="sticky top-0 z-20 bg-slate-50 shadow-[0_1px_0_0_rgb(226,232,240)]">
                    <tr>
                      <th className="w-10 px-3 py-3 print:hidden">
                        <input
                          type="checkbox"
                          checked={allVisibleSelected}
                          onChange={toggleAllVisible}
                          className="h-4 w-4 cursor-pointer rounded border-slate-300 accent-indigo-600"
                          aria-label="Выбрать все"
                        />
                      </th>
                      <SortTh label="№" k="num" sort={sort} onSort={onSort} />
                      <SortTh label="Ф.И.О." k="fio" sort={sort} onSort={onSort} />
                      <SortTh label="Пол" k="gender" sort={sort} onSort={onSort} />
                      <SortTh label="Профсоюз" k="union" sort={sort} onSort={onSort} />
                      <SortTh label="Место работы, должность" k="workplace" sort={sort} onSort={onSort} />
                      <SortTh label="Дата рождения" k="birth" sort={sort} onSort={onSort} />
                      <SortTh label="Паспорт" k="passport" sort={sort} onSort={onSort} />
                      <SortTh label="Телефон" k="phone" sort={sort} onSort={onSort} />
                      <SortTh label="Проживание" k="room" sort={sort} onSort={onSort} />
                      <th className="w-24 px-3 py-3 print:hidden" />
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {visible.length === 0 && (
                      <tr>
                        <td colSpan={11} className="px-4 py-16 text-center text-slate-500">
                          <div className="text-4xl">🔍</div>
                          <div className="mt-2 font-medium text-slate-700">Ничего не найдено</div>
                          <div className="text-sm">Измените параметры поиска или сбросьте фильтры</div>
                        </td>
                      </tr>
                    )}
                    {visible.map((p) => {
                      const info = p.room ? roomInfo.get(p.room) : undefined;
                      const mixed = !!info && info.m > 0 && info.f > 0;
                      const age = calcAge(p.birth);
                      const isSel = selected.has(p.id);
                      return (
                        <tr
                          key={p.id}
                          className={cn(
                            "align-top transition-colors hover:bg-slate-50",
                            isSel && "bg-indigo-50/70 hover:bg-indigo-50"
                          )}
                        >
                          <td className="px-3 py-3 print:hidden">
                            <input
                              type="checkbox"
                              checked={isSel}
                              onChange={() => toggleSelect(p.id)}
                              className="h-4 w-4 cursor-pointer rounded border-slate-300 accent-indigo-600"
                              aria-label={`Выбрать ${p.fio}`}
                            />
                          </td>
                          <td className="px-3 py-3 font-medium tabular-nums text-slate-500">{numOf.get(p.id)}</td>
                          <td className="min-w-[240px] px-3 py-3">
                            {(() => {
                              const t = participantTeam.get(p.id);
                              const tc = t ? TEAM_COLORS[t.color as TeamColorKey] : null;
                              return (
                                <div className="flex items-start gap-3">
                                  <span className="print:hidden relative shrink-0">
                                    <Avatar gender={p.gender} text={initials(p.fio)} />
                                    {tc && (
                                      <span
                                        className={cn(
                                          "absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full ring-2 ring-white",
                                          tc.dot
                                        )}
                                        title={`Команда: ${t!.name}`}
                                      />
                                    )}
                                  </span>
                                  <div className="min-w-0 flex-1">
                                    <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                                      <span className="font-semibold leading-snug text-slate-900">{p.fio}</span>
                                      {tc && (
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setTab("teams");
                                            setToast(`Команда: ${t!.name}`);
                                          }}
                                          className={cn(
                                            "inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-semibold uppercase ring-1 ring-inset",
                                            tc.chip
                                          )}
                                          title="Перейти к команде"
                                        >
                                          <span className={cn("h-1.5 w-1.5 rounded-full", tc.dot)} />
                                          {t!.name}
                                        </button>
                                      )}
                                    </div>
                                    {p.note && (
                                      <span className="mt-1 inline-block rounded bg-amber-100 px-1.5 py-0.5 text-[11px] font-semibold uppercase text-amber-800">
                                        {p.note}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              );
                            })()}
                          </td>
                          <td className="px-3 py-3">
                            <GenderBadge
                              gender={p.gender}
                              onClick={() => updateOne(p.id, { gender: p.gender === "М" ? "Ж" : "М" })}
                            />
                          </td>
                          <td className="min-w-[170px] max-w-[220px] px-3 py-3 text-xs leading-snug text-slate-600">
                            <button
                              onClick={() => patchFilters({ union: p.union })}
                              className="text-left hover:text-indigo-700 hover:underline print:no-underline"
                              title={`${p.union}\n(нажмите, чтобы отфильтровать)`}
                            >
                              {shortUnion(p.union)}
                            </button>
                          </td>
                          <td className="min-w-[300px] max-w-[420px] px-3 py-3 leading-snug text-slate-700">
                            <div className="line-clamp-4 print:line-clamp-none" title={p.workplace}>
                              {p.workplace || <span className="text-slate-400">—</span>}
                            </div>
                          </td>
                          <td className="whitespace-nowrap px-3 py-3">
                            <div className="tabular-nums text-slate-800">{p.birth || "—"}</div>
                            {age !== null && <div className="text-xs text-slate-500">{age} лет</div>}
                          </td>
                          <td className="min-w-[200px] max-w-[260px] px-3 py-3">
                            <div className="font-medium tabular-nums text-slate-800">{p.passport || "—"}</div>
                            {(p.issuedBy || p.issuedDate) && (
                              <div className="text-xs leading-snug text-slate-500">
                                {[p.issuedBy, p.issuedDate].filter(Boolean).join(", ")}
                              </div>
                            )}
                          </td>
                          <td className="whitespace-nowrap px-3 py-3 tabular-nums text-slate-700">
                            {p.phone || <span className="text-slate-400">—</span>}
                          </td>
                          <td className="px-3 py-3">
                            <RoomInput
                              value={p.room}
                              mixed={mixed}
                              occupants={info ? info.m + info.f : 0}
                              onCommit={(v) => updateOne(p.id, { room: v })}
                            />
                          </td>
                          <td className="px-3 py-3 print:hidden">
                            <div className="flex justify-end gap-1">
                              <button
                                onClick={() => setModal({ mode: "edit", id: p.id })}
                                className="rounded-lg p-2 text-slate-400 transition hover:bg-indigo-50 hover:text-indigo-600"
                                title="Редактировать"
                              >
                                <Icon name="pencil" size={16} />
                              </button>
                              <button
                                onClick={() => askDelete(p)}
                                className="rounded-lg p-2 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                                title="Удалить"
                              >
                                <Icon name="trash" size={16} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>

      <footer className="mx-auto max-w-[1600px] px-4 pb-8 text-center text-xs text-slate-400 print:hidden sm:px-6">
        Данные сохраняются автоматически в браузере · Пол определён по Ф.И.О. (отчество / имя) и может быть изменён вручную
      </footer>

      {modal && (
        <ParticipantModal
          key={modal.mode === "edit" ? modal.id : "new"}
          initial={editing}
          defaultUnion={filters.union}
          unions={unions}
          rooms={rooms}
          onSave={saveModal}
          onClose={() => setModal(null)}
        />
      )}

      {confirm && (
        <ConfirmDialog
          title={confirm.title}
          message={confirm.message}
          confirmLabel={confirm.confirmLabel}
          danger={confirm.danger ?? true}
          onConfirm={confirm.onConfirm}
          onCancel={() => setConfirm(null)}
        />
      )}

      {importData && (
        <ImportDialog
          data={importData.data}
          errors={importData.errors}
          existingCount={participants.length}
          onReplace={() => applyImport("replace")}
          onAppend={() => applyImport("append")}
          onCancel={() => setImportData(null)}
        />
      )}

      {toast && (
        <div className="animate-pop fixed bottom-6 left-1/2 z-[70] -translate-x-1/2 print:hidden">
          <div className="flex items-center gap-2 rounded-full bg-slate-900 px-5 py-2.5 text-sm font-medium text-white shadow-xl">
            <Icon name="check" size={16} className="text-emerald-400" />
            {toast}
          </div>
        </div>
      )}
    </div>
  );
}
