import type { Gender } from "../types";
import { cn } from "../utils/cn";

export function GenderBadge({
  gender,
  onClick,
  className,
}: {
  gender: Gender;
  onClick?: () => void;
  className?: string;
}) {
  const male = gender === "М";
  const cls = cn(
    "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset",
    male
      ? "bg-sky-50 text-sky-700 ring-sky-200"
      : "bg-rose-50 text-rose-700 ring-rose-200",
    onClick && "cursor-pointer transition hover:brightness-95 active:scale-95",
    className
  );
  const label = male ? "♂ Муж." : "♀ Жен.";
  if (onClick) {
    return (
      <button type="button" onClick={onClick} className={cls} title="Нажмите, чтобы изменить пол">
        {label}
      </button>
    );
  }
  return <span className={cls}>{label}</span>;
}

export function Avatar({ gender, text }: { gender: Gender; text: string }) {
  return (
    <span
      className={cn(
        "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-bold",
        gender === "М" ? "bg-sky-100 text-sky-700" : "bg-rose-100 text-rose-700"
      )}
    >
      {text}
    </span>
  );
}

export const inputCls =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 shadow-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200";
