import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import Icon from "./Icons";

interface Props {
  value: string;
  mixed: boolean;
  occupants: number;
  onCommit: (v: string) => void;
}

/** Поле «Номер проживания» с сохранением по Enter / потере фокуса. */
export default function RoomInput({ value, mixed, occupants, onCommit }: Props) {
  const [v, setV] = useState(value);
  useEffect(() => setV(value), [value]);

  const commit = () => {
    const t = v.trim();
    if (t !== value) onCommit(t);
    else setV(value);
  };

  return (
    <div className="flex items-center gap-1.5">
      <input
        value={v}
        list="rooms-list"
        onChange={(e) => setV(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") (e.target as HTMLInputElement).blur();
          if (e.key === "Escape") {
            setV(value);
            (e.target as HTMLInputElement).blur();
          }
        }}
        placeholder="—"
        aria-label="Номер проживания"
        className={cn(
          "w-20 rounded-md border bg-white px-2 py-1 text-center text-sm font-semibold outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200",
          value ? "border-emerald-300 bg-emerald-50 text-emerald-800" : "border-slate-200 text-slate-500",
          mixed && "border-amber-400 bg-amber-50 text-amber-800"
        )}
      />
      {mixed && (
        <span
          className="text-amber-500"
          title={`В номере ${value} (${occupants} чел.) проживают и мужчины, и женщины`}
        >
          <Icon name="alert" size={16} />
        </span>
      )}
    </div>
  );
}
