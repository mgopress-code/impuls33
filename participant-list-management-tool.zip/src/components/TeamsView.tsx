import { useMemo, useState } from "react";
import type { Gender, Participant, Team, TeamColorKey } from "../types";
import { TEAM_COLORS } from "../types";
import { cn } from "../utils/cn";
import { distributeTeams, shortUnion } from "../utils/helpers";
import Icon from "./Icons";
import { inputCls } from "./ui";

interface Props {
  participants: Participant[];
  teams: Team[];
  onTeamsChange: (teams: Team[]) => void;
  onEditParticipant: (id: string) => void;
  onConfirm: (opts: {
    title: string;
    message: string;
    confirmLabel: string;
    danger?: boolean;
    onConfirm: () => void;
  }) => void;
  onToast: (msg: string) => void;
}

const colorOptions = Object.values(TEAM_COLORS);

function newId() {
  return `t-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

function teamOf(teams: Team[], pid: string): Team | undefined {
  return teams.find((t) => t.memberIds.includes(pid));
}

function ColorDot({ color, className }: { color: TeamColorKey; className?: string }) {
  return <span className={cn("inline-block rounded-full ring-2 ring-white", TEAM_COLORS[color].dot, className)} />;
}

export default function TeamsView({
  participants,
  teams,
  onTeamsChange,
  onEditParticipant,
  onConfirm,
  onToast,
}: Props) {
  const [draftName, setDraftName] = useState("");
  const [draftColor, setDraftColor] = useState<TeamColorKey>("blue");
  const [filterGender, setFilterGender] = useState<"" | Gender>("");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  const participantsById = useMemo(() => {
    const m = new Map<string, Participant>();
    for (const p of participants) m.set(p.id, p);
    return m;
  }, [participants]);

  const unassigned = useMemo(() => {
    const s = query.trim().toLowerCase();
    return participants.filter(
      (p) =>
        !teamOf(teams, p.id) &&
        (!filterGender || p.gender === filterGender) &&
        (!s || p.fio.toLowerCase().includes(s) || p.union.toLowerCase().includes(s))
    );
  }, [participants, teams, filterGender, query]);

  const stats = useMemo(() => {
    const perTeam = teams.map((t) => {
      const members = t.memberIds.map((id) => participantsById.get(id)).filter(Boolean) as Participant[];
      const m = members.filter((p) => p.gender === "М").length;
      const f = members.length - m;
      const unions = new Set(members.map((p) => p.union));
      return { team: t, total: members.length, m, f, unions: unions.size, members };
    });
    const unassignedCount = participants.length - perTeam.reduce((s, x) => s + x.total, 0);
    return { perTeam, unassignedCount };
  }, [teams, participants, participantsById]);

  /* ------- действия ------- */
  const addTeam = () => {
    if (!draftName.trim()) return;
    const used = new Set(teams.map((t) => t.color));
    let color: TeamColorKey = draftColor;
    if (used.has(color)) {
      const free = colorOptions.find((c) => !used.has(c.id as TeamColorKey));
      color = free ? (free.id as TeamColorKey) : draftColor;
    }
    onTeamsChange([
      ...teams,
      {
        id: newId(),
        name: draftName.trim(),
        color,
        curators: [],
        memberIds: [],
      },
    ]);
    setDraftName("");
    onToast("Команда добавлена");
  };

  const removeTeam = (t: Team) => {
    onConfirm({
      title: `Удалить команду «${t.name}»?`,
      message: "Участники не удалятся, они просто перейдут в список «без команды».",
      confirmLabel: "Удалить",
      danger: true,
      onConfirm: () => {
        onTeamsChange(teams.filter((x) => x.id !== t.id));
        onToast(`Команда «${t.name}» удалена`);
      },
    });
  };

  const renameTeam = (id: string, name: string) =>
    onTeamsChange(teams.map((t) => (t.id === id ? { ...t, name } : t)));

  const setTeamColor = (id: string, color: TeamColorKey) =>
    onTeamsChange(teams.map((t) => (t.id === id ? { ...t, color } : t)));

  const setCurators = (id: string, value: string) => {
    const curators = value
      .split(/\n|,|;/)
      .map((s) => s.trim())
      .filter(Boolean);
    onTeamsChange(teams.map((t) => (t.id === id ? { ...t, curators } : t)));
  };

  const assignMember = (pid: string, teamId: string | "") => {
    // убрать из старой команды
    let next = teams.map((t) => ({ ...t, memberIds: t.memberIds.filter((x) => x !== pid) }));
    if (teamId) {
      next = next.map((t) => (t.id === teamId ? { ...t, memberIds: [...t.memberIds, pid] } : t));
    }
    onTeamsChange(next);
  };

  const removeFromTeam = (pid: string) => assignMember(pid, "");

  const clearAllTeams = () => {
    onConfirm({
      title: "Сбросить состав всех команд?",
      message: "Все участники будут выведены из команд. Кураторы и названия команд останутся.",
      confirmLabel: "Сбросить",
      danger: false,
      onConfirm: () => {
        onTeamsChange(teams.map((t) => ({ ...t, memberIds: [] })));
        onToast("Все команды очищены");
      },
    });
  };

  const autoDistribute = () => {
    if (teams.length === 0) {
      onToast("Сначала добавьте хотя бы одну команду");
      return;
    }
    const confirmed = () => {
      const assignment = distributeTeams(
        participants.map((p) => ({ id: p.id, gender: p.gender, union: p.union })),
        teams.map((t) => t.id)
      );
      onTeamsChange(
        teams.map((t) => ({ ...t, memberIds: assignment[t.id] ?? [] }))
      );
      // разворачиваем все карточки, чтобы было видно результат
      const exp: Record<string, boolean> = {};
      teams.forEach((t) => (exp[t.id] = true));
      setExpanded(exp);
      onToast(`Участники распределены по ${teams.length} командам`);
    };
    const someAssigned = teams.some((t) => t.memberIds.length > 0);
    if (someAssigned) {
      onConfirm({
        title: "Перемешать участников по командам?",
        message: "Текущее распределение будет заменено новым (с теми же командами и кураторами).",
        confirmLabel: "Разбить",
        danger: false,
        onConfirm: confirmed,
      });
    } else {
      confirmed();
    }
  };

  const toggleExpanded = (id: string) =>
    setExpanded((e) => ({ ...e, [id]: !e[id] }));

  return (
    <div className="space-y-6">
      {/* Панель управления */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">Команды форума</h2>
            <p className="mt-1 text-sm text-slate-500">
              Создавайте и переименовывайте команды, назначайте кураторов. Цвет точки отображается рядом с
              Ф.И.О. участника в общем списке.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={autoDistribute}
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700"
            >
              <Icon name="sparkles" size={16} /> Разбить случайно (сбалансированно)
            </button>
            <button
              onClick={clearAllTeams}
              disabled={!teams.some((t) => t.memberIds.length > 0)}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Icon name="reset" size={16} /> Очистить состав
            </button>
          </div>
        </div>

        {/* Добавление команды */}
        <div className="mt-4 grid gap-3 rounded-xl bg-slate-50 p-4 sm:grid-cols-[1fr_auto_auto]">
          <input
            value={draftName}
            onChange={(e) => setDraftName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addTeam()}
            placeholder="Название новой команды (например, «Синяя»)"
            className={inputCls}
          />
          <div className="flex items-center gap-1 rounded-lg bg-white p-1 ring-1 ring-slate-200">
            {colorOptions.map((c) => (
              <button
                key={c.id}
                onClick={() => setDraftColor(c.id as TeamColorKey)}
                title={c.name}
                className={cn(
                  "h-7 w-7 rounded-full transition",
                  c.dot,
                  draftColor === c.id ? "ring-2 ring-slate-900 ring-offset-2" : "opacity-70 hover:opacity-100"
                )}
              />
            ))}
          </div>
          <button
            onClick={addTeam}
            disabled={!draftName.trim()}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:bg-slate-300"
          >
            <Icon name="plus" size={16} /> Добавить
          </button>
        </div>
      </section>

      {/* Карточки команд */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {teams.length === 0 && (
          <div className="col-span-full rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500">
            Пока нет ни одной команды. Создайте команду выше или сразу нажмите «Разбить случайно» — но команды
            лучше добавить заранее.
          </div>
        )}
        {stats.perTeam.map(({ team, total, m, f, unions, members }) => {
          const c = TEAM_COLORS[team.color as TeamColorKey];
          const isOpen = expanded[team.id] ?? members.length > 0;
          return (
            <div key={team.id} className={cn("overflow-hidden rounded-2xl border bg-white shadow-sm", c.border)}>
              <div className={cn("bg-gradient-to-r p-4 text-white", c.gradient)}>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-3">
                    <span className={cn("h-10 w-10 shrink-0 rounded-full border-2 border-white/70", c.dot)} />
                    <div className="min-w-0">
                      <input
                        value={team.name}
                        onChange={(e) => renameTeam(team.id, e.target.value)}
                        className="w-full min-w-0 rounded-md bg-white/20 px-2 py-1 text-lg font-bold text-white placeholder:text-white/70 outline-none ring-0 focus:bg-white/30"
                      />
                      <div className="mt-1 flex flex-wrap gap-1 text-[11px] font-medium text-white/90">
                        <span className="rounded-full bg-black/20 px-2 py-0.5">{total} чел.</span>
                        <span className="rounded-full bg-sky-400/40 px-2 py-0.5">♂ {m}</span>
                        <span className="rounded-full bg-rose-400/40 px-2 py-0.5">♀ {f}</span>
                        <span className="rounded-full bg-black/20 px-2 py-0.5">профсоюзов: {unions}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <button
                      onClick={() => toggleExpanded(team.id)}
                      className="rounded-md p-1.5 text-white/90 transition hover:bg-black/20"
                      title={isOpen ? "Свернуть" : "Развернуть"}
                    >
                      <Icon name={isOpen ? "up" : "down"} size={16} />
                    </button>
                    <button
                      onClick={() => removeTeam(team)}
                      className="rounded-md p-1.5 text-white/90 transition hover:bg-black/20 hover:text-white"
                      title="Удалить команду"
                    >
                      <Icon name="trash" size={16} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4">
                {/* Цвет */}
                <div>
                  <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Цвет</div>
                  <div className="flex flex-wrap gap-1.5">
                    {colorOptions.map((co) => (
                      <button
                        key={co.id}
                        onClick={() => setTeamColor(team.id, co.id as TeamColorKey)}
                        title={co.name}
                        className={cn(
                          "h-6 w-6 rounded-full ring-1 ring-slate-200 transition",
                          co.dot,
                          team.color === co.id ? "ring-2 ring-slate-900 ring-offset-1" : "hover:scale-110"
                        )}
                      />
                    ))}
                  </div>
                </div>

                {/* Кураторы */}
                <div className="mt-3">
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Кураторы (через запятую или по одному на строку)
                  </label>
                  <textarea
                    value={team.curators.join(", ")}
                    onChange={(e) => setCurators(team.id, e.target.value)}
                    rows={Math.max(1, Math.min(3, team.curators.length || 1))}
                    placeholder="Ф.И.О. куратора(ов)"
                    className={cn(inputCls, "resize-y text-sm")}
                  />
                </div>

                {/* Состав */}
                <div className="mt-4">
                  <div className="mb-2 flex items-center justify-between">
                    <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Состав ({total})
                    </div>
                  </div>
                  {isOpen ? (
                    <ul className="divide-y divide-slate-100 rounded-lg border border-slate-100">
                      {members.length === 0 && (
                        <li className="px-3 py-4 text-center text-xs text-slate-400">
                          Пока пусто. Добавьте участников из правой колонки или нажмите «Разбить случайно».
                        </li>
                      )}
                      {members.map((p) => (
                        <li key={p.id} className="flex items-center gap-2 px-2 py-1.5">
                          <ColorDot color={team.color as TeamColorKey} className="h-3 w-3" />
                          <button
                            onClick={() => onEditParticipant(p.id)}
                            className="min-w-0 flex-1 truncate text-left text-sm text-slate-800 hover:text-indigo-600"
                            title={`${p.fio} · ${shortUnion(p.union)}`}
                          >
                            {p.fio}
                          </button>
                          <span className="text-[11px] text-slate-400">{p.gender}</span>
                          <button
                            onClick={() => removeFromTeam(p.id)}
                            className="rounded p-1 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                            title="Убрать из команды"
                          >
                            <Icon name="x" size={14} />
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <button
                      onClick={() => toggleExpanded(team.id)}
                      className="w-full rounded-lg border border-dashed border-slate-300 py-2 text-xs text-slate-500 transition hover:bg-slate-50"
                    >
                      Показать состав
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Правая колонка: нераспределённые */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="flex items-center gap-2 text-base font-semibold text-slate-900">
            <Icon name="users" className="text-indigo-600" />
            Без команды
            <span className="ml-1 rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-600">
              {stats.unassignedCount}
            </span>
          </h3>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex overflow-hidden rounded-lg border border-slate-200 text-xs">
              {(
                [
                  ["", "Все"],
                  ["М", "♂"],
                  ["Ж", "♀"],
                ] as const
              ).map(([v, label]) => (
                <button
                  key={v}
                  onClick={() => setFilterGender(v)}
                  className={cn(
                    "px-2.5 py-1 font-semibold transition",
                    filterGender === v ? "bg-indigo-600 text-white" : "bg-white text-slate-600 hover:bg-slate-50"
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск…"
              className={cn(inputCls, "w-52 py-1.5")}
            />
          </div>
        </div>

        <ul className="mt-3 max-h-[520px] space-y-1 overflow-y-auto pr-1">
          {unassigned.length === 0 && (
            <li className="rounded-lg bg-emerald-50 px-3 py-4 text-center text-sm font-medium text-emerald-700">
              {stats.unassignedCount === 0
                ? "Все участники распределены по командам 🎉"
                : "Никого не найдено по фильтру"}
            </li>
          )}
          {unassigned.map((p) => {
            const existing = teamOf(teams, p.id);
            return (
              <li
                key={p.id}
                className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-100 bg-slate-50 px-2.5 py-2"
              >
                <span
                  className={cn(
                    "h-2.5 w-2.5 shrink-0 rounded-full",
                    p.gender === "М" ? "bg-sky-500" : "bg-rose-400"
                  )}
                />
                <button
                  onClick={() => onEditParticipant(p.id)}
                  className="min-w-0 flex-1 truncate text-left"
                  title={p.union}
                >
                  <span className="block truncate text-sm font-medium text-slate-800">{p.fio}</span>
                  <span className="block truncate text-xs text-slate-500">{shortUnion(p.union)}</span>
                </button>
                {existing && (
                  <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-semibold text-amber-800">
                    в другой команде
                  </span>
                )}
                <div className="flex flex-wrap gap-1">
                  {teams.map((t) => {
                    const c = TEAM_COLORS[t.color as TeamColorKey];
                    const inThis = t.memberIds.includes(p.id);
                    return (
                      <button
                        key={t.id}
                        onClick={() => assignMember(p.id, t.id)}
                        title={t.name}
                        className={cn(
                          "h-6 w-6 rounded-full transition",
                          c.dot,
                          inThis
                            ? "ring-2 ring-slate-900 ring-offset-1"
                            : "opacity-60 hover:opacity-100 hover:ring-2 hover:ring-offset-1 " + c.ring
                        )}
                      />
                    );
                  })}
                  {teams.length > 0 && teams.some((t) => t.memberIds.includes(p.id)) && (
                    <button
                      onClick={() => removeFromTeam(p.id)}
                      className="rounded-md p-1 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                      title="Убрать из всех команд"
                    >
                      <Icon name="x" size={14} />
                    </button>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
