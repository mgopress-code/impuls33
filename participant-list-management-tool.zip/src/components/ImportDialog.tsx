import { useEffect, useState } from "react";
import type { ParticipantData } from "./ParticipantModal";
import { cn } from "../utils/cn";
import Icon from "./Icons";

interface Props {
  data: ParticipantData[];
  errors: string[];
  existingCount: number;
  onReplace: () => void;
  onAppend: () => void;
  onCancel: () => void;
}

export default function ImportDialog({
  data,
  errors,
  existingCount,
  onReplace,
  onAppend,
  onCancel,
}: Props) {
  const [showErrors, setShowErrors] = useState(false);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onCancel();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onCancel]);

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-sm"
      onMouseDown={(e) => e.target === e.currentTarget && onCancel()}
    >
      <div className="animate-pop w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl">
        <div className="flex items-start gap-4">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-indigo-600">
            <Icon name="upload" size={22} />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Импорт из CSV</h3>
            <p className="mt-1 text-sm leading-relaxed text-slate-600">
              Прочитано <b>{data.length}</b> участников из файла. Сейчас в списке:{" "}
              <b>{existingCount}</b>.
            </p>
          </div>
        </div>

        {errors.length > 0 && (
          <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
            <button
              onClick={() => setShowErrors((v) => !v)}
              className="flex w-full items-center justify-between font-semibold"
            >
              <span className="inline-flex items-center gap-1.5">
                <Icon name="alert" size={16} /> Замечания: {errors.length}
              </span>
              <span className="text-xs">{showErrors ? "Скрыть" : "Показать"}</span>
            </button>
            {showErrors && (
              <ul className="mt-2 max-h-40 list-disc space-y-0.5 overflow-y-auto pl-5 text-xs">
                {errors.map((e, i) => (
                  <li key={i}>{e}</li>
                ))}
              </ul>
            )}
          </div>
        )}

        <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button
            onClick={onCancel}
            className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
          >
            Отмена
          </button>
          <button
            onClick={onAppend}
            disabled={data.length === 0}
            className={cn(
              "rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-sm transition",
              data.length > 0
                ? "bg-indigo-600 hover:bg-indigo-700"
                : "cursor-not-allowed bg-slate-300"
            )}
          >
            Добавить к существующим
          </button>
          <button
            onClick={onReplace}
            disabled={data.length === 0}
            className={cn(
              "rounded-lg px-4 py-2 text-sm font-semibold shadow-sm transition",
              data.length > 0
                ? "bg-rose-600 text-white hover:bg-rose-700"
                : "cursor-not-allowed bg-slate-300 text-white"
            )}
          >
            Заменить список
          </button>
        </div>
      </div>
    </div>
  );
}
