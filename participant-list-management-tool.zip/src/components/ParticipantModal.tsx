import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import type { Gender, Participant } from "../types";
import { detectGender, fromIso, toIso } from "../utils/helpers";
import { cn } from "../utils/cn";
import Icon from "./Icons";
import { inputCls } from "./ui";

export type ParticipantData = Omit<Participant, "id"> & { team?: string };

interface Props {
  initial: Participant | null;
  defaultUnion: string;
  unions: string[];
  rooms: string[];
  onSave: (data: ParticipantData) => void;
  onClose: () => void;
}

interface FormState {
  fio: string;
  gender: Gender;
  union: string;
  workplace: string;
  birth: string; // iso
  passport: string;
  issuedBy: string;
  issuedDate: string; // iso
  phone: string;
  room: string;
  note: string;
}

function Field({
  label,
  required,
  error,
  children,
  className,
}: {
  label: string;
  required?: boolean;
  error?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
        {label}
        {required && <span className="text-rose-500"> *</span>}
      </span>
      {children}
      {error && <span className="mt-1 block text-xs text-rose-600">{error}</span>}
    </label>
  );
}

export default function ParticipantModal({
  initial,
  defaultUnion,
  unions,
  rooms,
  onSave,
  onClose,
}: Props) {
  const [form, setForm] = useState<FormState>(() => ({
    fio: initial?.fio ?? "",
    gender: initial?.gender ?? "М",
    union: initial?.union ?? defaultUnion,
    workplace: initial?.workplace ?? "",
    birth: initial ? toIso(initial.birth) : "",
    passport: initial?.passport ?? "",
    issuedBy: initial?.issuedBy ?? "",
    issuedDate: initial ? toIso(initial.issuedDate) : "",
    phone: initial?.phone ?? "",
    room: initial?.room ?? "",
    note: initial?.note ?? "",
  }));
  const [genderManual, setGenderManual] = useState(!!initial);
  const [errors, setErrors] = useState<{ fio?: string; union?: string }>({});

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const onFio = (v: string) => {
    setForm((f) => {
      const next = { ...f, fio: v };
      if (!genderManual) {
        const g = detectGender(v);
        if (g) next.gender = g;
      }
      return next;
    });
    if (errors.fio) setErrors((e) => ({ ...e, fio: undefined }));
  };

  const autoDetect = () => {
    const g = detectGender(form.fio);
    if (g) {
      set("gender", g);
      setGenderManual(false);
    }
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const errs: { fio?: string; union?: string } = {};
    if (!form.fio.trim()) errs.fio = "Укажите Ф.И.О.";
    if (!form.union.trim()) errs.union = "Укажите профсоюз или организацию";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    onSave({
      fio: form.fio.trim().replace(/\s+/g, " "),
      gender: form.gender,
      union: form.union.trim(),
      workplace: form.workplace.trim(),
      birth: fromIso(form.birth),
      passport: form.passport.trim(),
      issuedBy: form.issuedBy.trim(),
      issuedDate: fromIso(form.issuedDate),
      phone: form.phone.trim(),
      room: form.room.trim(),
      note: form.note.trim(),
    });
  };

  const detected = detectGender(form.fio);

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-900/50 p-4 backdrop-blur-sm sm:items-center"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <form
        onSubmit={submit}
        className="animate-pop my-4 w-full max-w-3xl rounded-2xl bg-white shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              {initial ? "Редактирование участника" : "Новый участник"}
            </h2>
            <p className="text-xs text-slate-500">
              Поля, отмеченные <span className="text-rose-500">*</span>, обязательны
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
            aria-label="Закрыть"
          >
            <Icon name="x" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 px-6 py-5 sm:grid-cols-6">
          <Field label="Ф.И.О." required error={errors.fio} className="sm:col-span-4">
            <input
              autoFocus
              className={cn(inputCls, errors.fio && "border-rose-400")}
              value={form.fio}
              onChange={(e) => onFio(e.target.value)}
              placeholder="Фамилия Имя Отчество"
            />
          </Field>

          <div className="sm:col-span-2">
            <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
              Пол
            </span>
            <div className="flex overflow-hidden rounded-lg border border-slate-300 shadow-sm">
              {(["М", "Ж"] as Gender[]).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => {
                    set("gender", g);
                    setGenderManual(true);
                  }}
                  className={cn(
                    "flex-1 px-3 py-2 text-sm font-semibold transition",
                    form.gender === g
                      ? g === "М"
                        ? "bg-sky-600 text-white"
                        : "bg-rose-500 text-white"
                      : "bg-white text-slate-600 hover:bg-slate-50"
                  )}
                >
                  {g === "М" ? "♂ Мужской" : "♀ Женский"}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={autoDetect}
              disabled={!detected}
              className="mt-1.5 inline-flex items-center gap-1 text-xs text-indigo-600 transition hover:text-indigo-800 disabled:cursor-not-allowed disabled:text-slate-400"
            >
              <Icon name="sparkles" size={13} />
              {genderManual ? "Определить по Ф.И.О." : "Определён по Ф.И.О."}
            </button>
          </div>

          <Field label="Профсоюз / организация" required error={errors.union} className="sm:col-span-6">
            <input
              list="unions-list"
              className={cn(inputCls, errors.union && "border-rose-400")}
              value={form.union}
              onChange={(e) => {
                set("union", e.target.value);
                if (errors.union) setErrors((x) => ({ ...x, union: undefined }));
              }}
              placeholder="Выберите из списка или введите новое название"
            />
            <datalist id="unions-list">
              {unions.map((u) => (
                <option key={u} value={u} />
              ))}
            </datalist>
          </Field>

          <Field label="Место работы, должность" className="sm:col-span-6">
            <textarea
              rows={3}
              className={cn(inputCls, "resize-y")}
              value={form.workplace}
              onChange={(e) => set("workplace", e.target.value)}
              placeholder="Организация, должность"
            />
          </Field>

          <Field label="Дата рождения" className="sm:col-span-2">
            <input
              type="date"
              className={inputCls}
              value={form.birth}
              onChange={(e) => set("birth", e.target.value)}
            />
          </Field>
          <Field label="Паспорт (серия, номер)" className="sm:col-span-2">
            <input
              className={inputCls}
              value={form.passport}
              onChange={(e) => set("passport", e.target.value)}
              placeholder="МС 1234567"
            />
          </Field>
          <Field label="Контактный телефон" className="sm:col-span-2">
            <input
              type="tel"
              className={inputCls}
              value={form.phone}
              onChange={(e) => set("phone", e.target.value)}
              placeholder="+375291234567"
            />
          </Field>

          <Field label="Кем выдан" className="sm:col-span-4">
            <input
              className={inputCls}
              value={form.issuedBy}
              onChange={(e) => set("issuedBy", e.target.value)}
              placeholder="Октябрьским РУВД г. Минска"
            />
          </Field>
          <Field label="Когда выдан" className="sm:col-span-2">
            <input
              type="date"
              className={inputCls}
              value={form.issuedDate}
              onChange={(e) => set("issuedDate", e.target.value)}
            />
          </Field>

          <Field label="Номер проживания" className="sm:col-span-2">
            <input
              list="modal-rooms"
              className={inputCls}
              value={form.room}
              onChange={(e) => set("room", e.target.value)}
              placeholder="Напр. 305"
            />
            <datalist id="modal-rooms">
              {rooms.map((r) => (
                <option key={r} value={r} />
              ))}
            </datalist>
          </Field>
          <Field label="Примечание" className="sm:col-span-4">
            <input
              className={inputCls}
              value={form.note}
              onChange={(e) => set("note", e.target.value)}
              placeholder="Например: замена, руководитель группы"
            />
          </Field>
        </div>

        <div className="flex flex-col-reverse gap-3 border-t border-slate-200 bg-slate-50 px-6 py-4 sm:flex-row sm:justify-end sm:rounded-b-2xl">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-slate-300 bg-white px-5 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-100"
          >
            Отмена
          </button>
          <button
            type="submit"
            className="rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700"
          >
            {initial ? "Сохранить изменения" : "Добавить участника"}
          </button>
        </div>
      </form>
    </div>
  );
}
