import { useMemo, useState } from "react";
import type { Gender, Participant } from "../types";
import { cn } from "../utils/cn";
import { naturalCompare, shortUnion } from "../utils/helpers";
import Icon from "./Icons";
import { GenderBadge, inputCls } from "./ui";

interface Props {
  participants: Participant[];
  onAssign: (ids: string[], room: string) => void;
  onEdit: (id: string) => void;
}

export default function RoomsView({ participants, onAssign, onEdit }: Props) {
  const [targetRoom, setTargetRoom] = useState("");
  const [roomError, setRoomError] = useState(false);
  const [gender, setGender] = useState<"" | Gender>("");
  const [q, setQ] = useState("");

  const rooms = useMemo(() => {
    const map = new Map<string, Participant[]>();
    for (const p of participants) {
      if (!p.room) continue;
      const arr = map.get(p.room) ?? [];
      arr.push(p);
      map.set(p.room, arr);
    }
    return [...map.entries()].sort((a, b) => naturalCompare(a[0], b[0]));
  }, [participants]);

  const unplaced = useMemo(() => {
    const s = q.trim().toLowerCase();
    return participants.filter(
      (p) =>
        !p.room &&
        (!gender || p.gender === gender) &&
        (!s || p.fio.toLowerCase().includes(s) || p.union.toLowerCase().includes(s))
    );
  }, [participants, gender, q]);

  const totalUnplaced = participants.filter((p) => !p.room).length;

  const place = (id: string) => {
    const r = targetRoom.trim();
    if (!r) {
      setRoomError(true);
      return;
    }
    setRoomError(false);
    onAssign([id], r);
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(320px,400px)_1fr]">
      {/* Быстрое заселение */}
      <section className="h-fit rounded-2xl border border-slate-200 bg-white p-5 shadow-sm lg:sticky lg:top-4">
        <h3 className="flex items-center gap-2 text-base font-semibold text-slate-900">
          <Icon name="bed" className="text-indigo-600" />
          Быстрое заселение
        </h3>
        <p className="mt-1 text-sm text-slate-500">
          Укажите номер и нажимайте на участников — они будут заселены в этот номер.
        </p>

        <label className="mt-4 block text-xs font-semibold uppercase tracking-wide text-slate-500">
          Номер проживания
        </label>
        <input
          list="rooms-list"
          value={targetRoom}
          onChange={(e) => {
            setTargetRoom(e.target.value);
            setRoomError(false);
          }}
          placeholder="Например: 305"
          className={cn(inputCls, "mt-1", roomError && "border-rose-400 ring-2 ring-rose-200")}
        />
        {roomError && <p className="mt-1 text-xs text-rose-600">Сначала введите номер проживания</p>}

        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
            Без номера ({totalUnplaced})
          </span>
          <div className="flex overflow-hidden rounded-lg border border-slate-200 text-xs">
            {([
              ["", "Все"],
              ["М", "М"],
              ["Ж", "Ж"],
            ] as const).map(([v, label]) => (
              <button
                key={v}
                onClick={() => setGender(v)}
                className={cn(
                  "px-3 py-1 font-semibold transition",
                  gender === v ? "bg-indigo-600 text-white" : "bg-white text-slate-600 hover:bg-slate-50"
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Поиск по Ф.И.О. или профсоюзу"
          className={cn(inputCls, "mt-2")}
        />

        <ul className="mt-3 max-h-[420px] space-y-1 overflow-y-auto pr-1">
          {unplaced.length === 0 && (
            <li className="rounded-lg bg-slate-50 px-3 py-6 text-center text-sm text-slate-500">
              {totalUnplaced === 0 ? "Все участники размещены 🎉" : "Никого не найдено"}
            </li>
          )}
          {unplaced.map((p) => (
            <li key={p.id}>
              <button
                onClick={() => place(p.id)}
                className="flex w-full items-center gap-2 rounded-lg border border-transparent px-2.5 py-2 text-left transition hover:border-indigo-200 hover:bg-indigo-50"
              >
                <span
                  className={cn(
                    "h-2.5 w-2.5 shrink-0 rounded-full",
                    p.gender === "М" ? "bg-sky-500" : "bg-rose-400"
                  )}
                />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium text-slate-800">{p.fio}</span>
                  <span className="block truncate text-xs text-slate-500">{shortUnion(p.union)}</span>
                </span>
                <Icon name="plus" size={16} className="text-indigo-500" />
              </button>
            </li>
          ))}
        </ul>
      </section>

      {/* Карточки номеров */}
      <section>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-900">Номера проживания ({rooms.length})</h3>
        </div>
        {rooms.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500">
            Пока никто не заселён. Укажите номер проживания слева или в таблице участников.
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {rooms.map(([room, people]) => {
              const m = people.filter((p) => p.gender === "М").length;
              const f = people.length - m;
              const mixed = m > 0 && f > 0;
              return (
                <div
                  key={room}
                  className={cn(
                    "rounded-2xl border bg-white p-4 shadow-sm",
                    mixed ? "border-amber-300 ring-1 ring-amber-200" : "border-slate-200"
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs font-medium uppercase tracking-wide text-slate-400">Номер</div>
                      <div className="text-2xl font-bold leading-none text-slate-900">{room}</div>
                    </div>
                    <div className="flex flex-col items-end gap-1 text-xs">
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 font-semibold text-slate-600">
                        {people.length} чел.
                      </span>
                      <span className="text-slate-500">
                        <span className="text-sky-600">♂ {m}</span> · <span className="text-rose-500">♀ {f}</span>
                      </span>
                    </div>
                  </div>

                  {mixed && (
                    <div className="mt-3 flex items-center gap-1.5 rounded-lg bg-amber-50 px-2.5 py-1.5 text-xs font-medium text-amber-800">
                      <Icon name="alert" size={14} />
                      Смешанное проживание (М и Ж)
                    </div>
                  )}

                  <ul className="mt-3 divide-y divide-slate-100">
                    {people.map((p) => (
                      <li key={p.id} className="flex items-center gap-2 py-2">
                        <GenderBadge gender={p.gender} className="px-1.5" />
                        <button
                          onClick={() => onEdit(p.id)}
                          className="min-w-0 flex-1 truncate text-left text-sm text-slate-800 hover:text-indigo-600"
                          title={`${p.fio} — ${shortUnion(p.union)}`}
                        >
                          {p.fio}
                        </button>
                        <button
                          onClick={() => onAssign([p.id], "")}
                          className="rounded-md p-1 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                          title="Выселить из номера"
                        >
                          <Icon name="x" size={15} />
                        </button>
                      </li>
                    ))}
                  </ul>

                  <button
                    onClick={() => {
                      setTargetRoom(room);
                      setRoomError(false);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    <Icon name="plus" size={14} /> Заселить ещё в этот номер
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
