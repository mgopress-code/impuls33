import type { Gender, Participant } from "../types";
import type { ParticipantData } from "../components/ParticipantModal";

/** Определение пола по ФИО (отчество → имя). Возвращает null, если не удалось. */
export function detectGender(fio: string): Gender | null {
  const words = fio
    .trim()
    .toLowerCase()
    .replace(/ё/g, "е")
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return null;

  // 1. Отчество (ищем после фамилии, т.к. фамилии вида «Климович» похожи на отчества)
  for (const w of words.slice(1)) {
    if (/(овна|евна|ична|инична|чна|кызы|кизи|овну|евну|ичну)$/.test(w)) return "Ж";
    if (/(ович|евич|ьич|оглы|улы)$/.test(w) || w === "оглы") return "М";
  }

  // 2. Имя (второе слово)
  const name = words[1];
  if (!name) return null;
  const maleOnA = ["илья", "никита", "данила", "кузьма", "лука", "фома", "миша", "саша", "женя"];
  if (maleOnA.includes(name)) return "М";
  if (/[ая]$/.test(name)) return "Ж";
  if (/ь$/.test(name)) return name === "любовь" ? "Ж" : "М";
  if (/[бвгджзйклмнпрстфхцчшщ]$/.test(name)) return "М";
  return null;
}

export function parseDate(s: string): Date | null {
  const m = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(s.trim());
  if (!m) return null;
  const d = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]));
  return isNaN(d.getTime()) ? null : d;
}

export function calcAge(birth: string, now = new Date()): number | null {
  const d = parseDate(birth);
  if (!d) return null;
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--;
  return age;
}

/** дд.мм.гггг → гггг-мм-дд (для input[type=date]) */
export function toIso(s: string): string {
  const d = parseDate(s);
  if (!d) return "";
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/** гггг-мм-дд → дд.мм.гггг */
export function fromIso(s: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  return m ? `${m[3]}.${m[2]}.${m[1]}` : "";
}

export function shortUnion(u: string): string {
  const s = u
    .replace(/^Белорусский профсоюз работников\s+/i, "")
    .replace(/^Белорусский профсоюз\s+/i, "")
    .replace(/^Учреждение образования\s+/i, "УО ");
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export function naturalCompare(a: string, b: string): number {
  return a.localeCompare(b, "ru", { numeric: true, sensitivity: "base" });
}

export function initials(fio: string): string {
  const w = fio.trim().split(/\s+/);
  return ((w[0]?.[0] ?? "") + (w[1]?.[0] ?? "")).toUpperCase();
}

/**
 * Разобрать CSV с разделителем `;` (или `,`), с учётом кавычек и экранирования кавычек.
 * Поддерживает переносы строк внутри кавычек и необязательный UTF-8 BOM.
 */
export function parseCsv(text: string): string[][] {
  let s = text.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
  const rows: string[][] = [];
  let cur: string[] = [];
  let field = "";
  let inQuotes = false;
  let i = 0;
  // Авто-определение разделителя: первая строка, если есть ';' — используем его, иначе ','.
  const firstLine = s.split("\n", 1)[0];
  const delim = firstLine.includes(";") ? ";" : firstLine.includes(",") ? "," : ";";
  while (i < s.length) {
    const c = s[i];
    if (inQuotes) {
      if (c === '"') {
        if (s[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i++;
        continue;
      }
      field += c;
      i++;
      continue;
    }
    if (c === '"') {
      inQuotes = true;
      i++;
      continue;
    }
    if (c === delim) {
      cur.push(field);
      field = "";
      i++;
      continue;
    }
    if (c === "\n") {
      cur.push(field);
      rows.push(cur);
      cur = [];
      field = "";
      i++;
      continue;
    }
    field += c;
    i++;
  }
  // хвост
  if (field.length > 0 || cur.length > 0) {
    cur.push(field);
    rows.push(cur);
  }
  return rows.filter((r) => r.some((cell) => cell.trim().length > 0));
}

/**
 * Нормализовать телефон, дату, пол и разобрать CSV-строки в ParticipantData.
 * Ожидает колонки в том же порядке, в котором их выгружает exportCsv:
 * 0 №, 1 ФИО, 2 Пол, 3 Профсоюз, 4 Место работы, 5 Дата рождения, 6 Возраст (игнор),
 * 7 Паспорт, 8 Кем выдан, 9 Дата выдачи, 10 Телефон, 11 Номер, 12 Примечание,
 * 13 Команда, 14 Цвет, 15 Кураторы.
 */
export function importCsvToParticipants(text: string): {
  ok: ParticipantData[];
  errors: string[];
  teams: { name: string; color: string; curators: string[] }[];
} {
  const rows = parseCsv(text);
  if (rows.length === 0) return { ok: [], errors: ["Файл пустой"], teams: [] };
  const header = rows[0].map((h) => h.trim().toLowerCase());
  const idx = (needles: string[]): number => {
    for (const n of needles) {
      const i = header.findIndex((h) => h.includes(n));
      if (i >= 0) return i;
    }
    return -1;
  };
  const iFio = idx(["фио", "ф.и.о", "fio"]);
  const iUnion = idx(["профсоюз", "союз", "organization"]);
  const iGender = idx(["пол", "gender"]);
  const iWork = idx(["место работы", "должность", "work"]);
  const iBirth = idx(["дата рождения", "рождения", "birth"]);
  const iPass = idx(["паспорт", "документ"]);
  const iIssuedBy = idx(["кем выдан"]);
  const iIssuedDate = idx(["когда выдан", "дата выдачи"]);
  const iPhone = idx(["телефон", "контакт", "phone"]);
  const iRoom = idx(["проживания", "номер прожив", "комната", "room"]);
  const iNote = idx(["примечание", "note"]);
  const iTeam = idx(["команда", "team"]);
  const iTeamColor = idx(["цвет команды", "цвет", "color"]);
  const iCurators = idx(["кураторы", "curator"]);

  const ok: ParticipantData[] = [];
  const errors: string[] = [];
  const teamMap = new Map<string, { name: string; color: string; curators: string[] }>();

  for (let r = 1; r < rows.length; r++) {
    const row = rows[r];
    const pick = (i: number) => (i >= 0 ? (row[i] ?? "").trim() : "");
    const fio = pick(iFio >= 0 ? iFio : 1);
    if (!fio) {
      errors.push(`Строка ${r + 1}: пропущено Ф.И.О.`);
      continue;
    }
    let genderRaw = pick(iGender >= 0 ? iGender : 2).toUpperCase();
    let gender: Gender;
    if (genderRaw.startsWith("М") || genderRaw.includes("МУЖ")) gender = "М";
    else if (genderRaw.startsWith("Ж") || genderRaw.includes("ЖЕН")) gender = "Ж";
    else gender = detectGender(fio) ?? "М";
    const union = pick(iUnion >= 0 ? iUnion : 3);

    const teamName = pick(iTeam);
    let teamColor = pick(iTeamColor);
    const curatorsRaw = pick(iCurators);
    let curators: string[] = [];
    if (curatorsRaw) {
      // Кураторы разделены "; " внутри ячейки
      curators = curatorsRaw
        .split(/;|,|\n/)
        .map((s) => s.trim())
        .filter(Boolean);
    }
    // Поддерживаем CSV, сгенерированный нами: внутри csvCell кураторы разделены "; "
    if (teamName) {
      const existing = teamMap.get(teamName);
      if (!existing) {
        // нормализуем цвет
        let color = teamColor.toLowerCase().trim();
        if (!color || !["orange", "green", "red", "blue", "purple", "yellow", "teal", "pink"].includes(color)) {
          color = ""; // оставляем на откуп приложению (дефолтные)
        }
        teamMap.set(teamName, { name: teamName, color, curators });
      } else if (!existing.curators.length && curators.length) {
        existing.curators = curators;
      } else if (curators.length && !existing.curators.length) {
        existing.curators = curators;
      }
    }

    ok.push({
      fio: fio.replace(/\s+/g, " ").trim(),
      gender,
      union: union || "(без профсоюза)",
      workplace: pick(iWork >= 0 ? iWork : 4),
      birth: pick(iBirth >= 0 ? iBirth : 5),
      passport: pick(iPass >= 0 ? iPass : 7),
      issuedBy: pick(iIssuedBy),
      issuedDate: pick(iIssuedDate),
      phone: pick(iPhone >= 0 ? iPhone : 10),
      room: pick(iRoom >= 0 ? iRoom : 11),
      note: pick(iNote >= 0 ? iNote : 12),
      team: teamName || undefined,
    });
  }
  return { ok, errors, teams: [...teamMap.values()] };
}

function csvCell(v: string | number): string {
  const s = String(v ?? "");
  return `"${s.replace(/"/g, '""')}"`;
}

/**
 * Сбалансированное разбиение участников по командам.
 * Условия:
 * 1) Примерно равное число мужчин и женщин внутри каждой команды.
 * 2) Равномерное распределение участников по профсоюзам (чтобы один профсоюз не скапливался в одной команде).
 *
 * Алгоритм: жадно назначаем по очереди М и Ж; в рамках пола сначала раздаём из самого
 * представленного профсоюза, выбирая команду, в которой этот профсоюз представлен меньше всего,
 * а при равенстве — самую маленькую по размеру (и с меньшим числом уже назначенных этого пола).
 */
export function distributeTeams<T extends { id: string; gender: Gender; union: string }>(
  people: T[],
  teamIds: string[]
): Record<string, string[]> {
  const result: Record<string, string[]> = Object.fromEntries(teamIds.map((id) => [id, []]));
  const counts: Record<string, { total: number; m: number; f: number; unions: Record<string, number> }> =
    Object.fromEntries(
      teamIds.map((id) => [id, { total: 0, m: 0, f: 0, unions: {} }])
    );

  if (teamIds.length === 0) return result;
  const byGender: Record<Gender, T[]> = { М: [], Ж: [] };
  for (const p of people) byGender[p.gender].push(p);

  const score = (teamId: string, union: string, gender: Gender): [number, number, number] => {
    const c = counts[teamId];
    const unionCount = c.unions[union] ?? 0;
    const sameGender = gender === "М" ? c.m : c.f;
    return [unionCount, c.total, sameGender];
  };

  const assign = (p: T) => {
    const best = teamIds
      .slice()
      .sort((a, b) => {
        const sa = score(a, p.union, p.gender);
        const sb = score(b, p.union, p.gender);
        for (let i = 0; i < sa.length; i++) {
          if (sa[i] !== sb[i]) return sa[i] - sb[i];
        }
        return a.localeCompare(b);
      })[0];
    result[best].push(p.id);
    counts[best].total++;
    if (p.gender === "М") counts[best].m++;
    else counts[best].f++;
    counts[best].unions[p.union] = (counts[best].unions[p.union] ?? 0) + 1;
  };

  const pool: T[] = [];
  const mArr = [...byGender.М];
  const fArr = [...byGender.Ж];
  // перетасовываем Фишером–Йетсом для случайности при равенстве счётов
  const shuffle = <U,>(a: U[]) => {
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
  };
  shuffle(mArr);
  shuffle(fArr);
  // Чередуем пола, но всегда берём из текущего самого большого остатка, чтобы не было перекоса
  let mi = 0;
  let fi = 0;
  while (mi < mArr.length || fi < fArr.length) {
    const mLeft = mArr.length - mi;
    const fLeft = fArr.length - fi;
    // Начинаем с того пола, которого осталось больше в абсолютных числах, но чередуем когда они равны
    const startWithM = mLeft >= fLeft;
    if (startWithM && mi < mArr.length) {
      pool.push(mArr[mi++]);
    }
    if (fi < fArr.length) {
      pool.push(fArr[fi++]);
    }
    if (!startWithM && mi < mArr.length) {
      pool.push(mArr[mi++]);
    }
  }
  pool.forEach(assign);
  return result;
}

export function exportCsv(
  rows: Participant[],
  numOf: (id: string) => number,
  filename: string,
  opts: { teamOf?: (id: string) => { name: string; color: string; curators: string[] } | null } = {}
) {
  const header = [
    "№ п/п",
    "Ф.И.О.",
    "Пол",
    "Профсоюз",
    "Место работы, должность",
    "Дата рождения",
    "Возраст",
    "Паспорт (серия, номер)",
    "Кем выдан",
    "Дата выдачи",
    "Контактный телефон",
    "Номер проживания",
    "Примечание",
    "Команда",
    "Цвет команды",
    "Кураторы команды",
  ];
  const lines = [header.map(csvCell).join(";")];
  for (const p of rows) {
    const tm = opts.teamOf?.(p.id) ?? null;
    lines.push(
      [
        numOf(p.id),
        p.fio,
        p.gender,
        p.union,
        p.workplace,
        p.birth,
        calcAge(p.birth) ?? "",
        p.passport,
        p.issuedBy,
        p.issuedDate,
        p.phone,
        p.room,
        p.note,
        tm?.name ?? "",
        tm?.color ?? "",
        tm ? tm.curators.join("; ") : "",
      ]
        .map(csvCell)
        .join(";")
    );
  }
  const blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
