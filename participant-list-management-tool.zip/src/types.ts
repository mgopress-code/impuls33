export type Gender = "М" | "Ж";

export interface Participant {
  id: string;
  union: string; // профсоюз / организация
  fio: string;
  gender: Gender;
  workplace: string;
  birth: string; // дд.мм.гггг
  passport: string; // серия и номер
  issuedBy: string; // кем выдан
  issuedDate: string; // дд.мм.гггг
  phone: string;
  room: string; // номер проживания
  note: string;
}

export type SortKey =
  | "num"
  | "fio"
  | "gender"
  | "union"
  | "workplace"
  | "birth"
  | "age"
  | "passport"
  | "issuedDate"
  | "phone"
  | "room"
  | "team";

export type SortDir = "asc" | "desc";

export interface Team {
  id: string;
  name: string;
  color: string; // tailwind-совместимый ключ, см. TEAM_COLORS
  curators: string[]; // массив Ф.И.О. кураторов (произвольные строки)
  memberIds: string[]; // id участников
}

export const TEAM_COLORS = {
  orange: {
    id: "orange",
    name: "Оранжевая",
    dot: "bg-orange-500",
    bg: "bg-orange-50",
    border: "border-orange-300",
    ring: "ring-orange-300",
    text: "text-orange-700",
    chip: "bg-orange-100 text-orange-800 ring-orange-200",
    header: "bg-orange-500 text-white",
    gradient: "from-orange-500 to-amber-500",
  },
  green: {
    id: "green",
    name: "Зелёная",
    dot: "bg-emerald-500",
    bg: "bg-emerald-50",
    border: "border-emerald-300",
    ring: "ring-emerald-300",
    text: "text-emerald-700",
    chip: "bg-emerald-100 text-emerald-800 ring-emerald-200",
    header: "bg-emerald-500 text-white",
    gradient: "from-emerald-500 to-green-500",
  },
  red: {
    id: "red",
    name: "Красная",
    dot: "bg-rose-500",
    bg: "bg-rose-50",
    border: "border-rose-300",
    ring: "ring-rose-300",
    text: "text-rose-700",
    chip: "bg-rose-100 text-rose-800 ring-rose-200",
    header: "bg-rose-500 text-white",
    gradient: "from-rose-500 to-red-500",
  },
  blue: {
    id: "blue",
    name: "Синяя",
    dot: "bg-sky-500",
    bg: "bg-sky-50",
    border: "border-sky-300",
    ring: "ring-sky-300",
    text: "text-sky-700",
    chip: "bg-sky-100 text-sky-800 ring-sky-200",
    header: "bg-sky-500 text-white",
    gradient: "from-sky-500 to-blue-500",
  },
  purple: {
    id: "purple",
    name: "Фиолетовая",
    dot: "bg-violet-500",
    bg: "bg-violet-50",
    border: "border-violet-300",
    ring: "ring-violet-300",
    text: "text-violet-700",
    chip: "bg-violet-100 text-violet-800 ring-violet-200",
    header: "bg-violet-500 text-white",
    gradient: "from-violet-500 to-fuchsia-500",
  },
  yellow: {
    id: "yellow",
    name: "Жёлтая",
    dot: "bg-amber-400",
    bg: "bg-amber-50",
    border: "border-amber-300",
    ring: "ring-amber-300",
    text: "text-amber-700",
    chip: "bg-amber-100 text-amber-800 ring-amber-200",
    header: "bg-amber-400 text-amber-950",
    gradient: "from-amber-400 to-yellow-400",
  },
  teal: {
    id: "teal",
    name: "Бирюзовая",
    dot: "bg-teal-500",
    bg: "bg-teal-50",
    border: "border-teal-300",
    ring: "ring-teal-300",
    text: "text-teal-700",
    chip: "bg-teal-100 text-teal-800 ring-teal-200",
    header: "bg-teal-500 text-white",
    gradient: "from-teal-500 to-cyan-500",
  },
  pink: {
    id: "pink",
    name: "Розовая",
    dot: "bg-pink-500",
    bg: "bg-pink-50",
    border: "border-pink-300",
    ring: "ring-pink-300",
    text: "text-pink-700",
    chip: "bg-pink-100 text-pink-800 ring-pink-200",
    header: "bg-pink-500 text-white",
    gradient: "from-pink-500 to-rose-500",
  },
} as const;

export type TeamColorKey = keyof typeof TEAM_COLORS;

export const DEFAULT_TEAMS: Team[] = [
  {
    id: "team-orange",
    name: "Оранжевая",
    color: "orange",
    curators: ["Федорова Анна Сергеевна"],
    memberIds: [],
  },
  {
    id: "team-green",
    name: "Зелёная",
    color: "green",
    curators: ["Колеснева Александра Владимировна"],
    memberIds: [],
  },
  {
    id: "team-red",
    name: "Красная",
    color: "red",
    curators: ["Михнюкевич Анастасия Васильевна"],
    memberIds: [],
  },
];
