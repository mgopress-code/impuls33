/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_FORUM_BACKEND?: "kv" | "local";
}
interface ImportMeta {
  readonly env: ImportMetaEnv;
}
