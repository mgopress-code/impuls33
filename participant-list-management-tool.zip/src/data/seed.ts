import type { Participant } from "../types";
import { seedA } from "./seedA";
import { seedB } from "./seedB";

export function buildSeed(): Participant[] {
  const out: Participant[] = [];
  let n = 0;
  for (const section of [...seedA, ...seedB]) {
    for (const r of section.rows) {
      n++;
      out.push({
        id: `seed-${n}`,
        union: section.union,
        fio: r[0],
        gender: r[1],
        workplace: r[2],
        birth: r[3],
        passport: r[4],
        issuedBy: r[5],
        issuedDate: r[6],
        phone: r[7],
        room: "",
        note: r[8] ?? "",
      });
    }
  }
  return out;
}
