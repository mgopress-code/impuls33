import type { Gender } from "../types";

/** [ФИО, пол, место работы, дата рождения, паспорт, кем выдан, дата выдачи, телефон, примечание?] */
export type Row = [
  fio: string,
  gender: Gender,
  workplace: string,
  birth: string,
  passport: string,
  issuedBy: string,
  issuedDate: string,
  phone: string,
  note?: string,
];

export interface Section {
  union: string;
  rows: Row[];
}
