import type { Participant, Team } from "../types";

export interface AppData {
  participants: Participant[];
  teams: Team[];
  version: number;
  updatedAt: string;
}

export interface StorageBackend {
  kind: "local" | "vercel-kv";
  load(): Promise<AppData | null>;
  save(data: AppData): Promise<void>;
}

export const CURRENT_VERSION = 2;

const K = "forum-app-data-v2";

export const localBackend: StorageBackend = {
  kind: "local",
  async load() {
    try {
      const raw = localStorage.getItem(K);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as AppData;
      return parsed;
    } catch {
      return null;
    }
  },
  async save(data) {
    localStorage.setItem(K, JSON.stringify(data));
  },
};

export const vercelBackend: StorageBackend = {
  kind: "vercel-kv",
  async load() {
    const res = await fetch("/api/data", { cache: "no-store" });
    if (!res.ok) {
      if (res.status === 404) return null;
      throw new Error(`Не удалось загрузить данные: ${res.status}`);
    }
    return (await res.json()) as AppData;
  },
  async save(data) {
    const res = await fetch("/api/data", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const t = await res.text().catch(() => "");
      throw new Error(`Не удалось сохранить: ${res.status} ${t}`);
    }
  },
};

export function pickBackend(): StorageBackend {
  // При сборке под Vercel переменная VITE_FORUM_BACKEND=kv включает серверное хранилище.
  // Если не указана — используем локальное хранилище браузера.
  if (import.meta.env.VITE_FORUM_BACKEND === "kv") return vercelBackend;
  return localBackend;
}
